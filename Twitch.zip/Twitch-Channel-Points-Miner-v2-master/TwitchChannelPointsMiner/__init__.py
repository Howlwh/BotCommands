# -*- coding: utf-8 -*-
__version__ = "1.8.1"
from .TwitchChannelPointsMiner import TwitchChannelPointsMiner

__all__ = [
    "TwitchChannelPointsMiner",
]
